#ifndef LISTES_H
#define LISTES_H

#include <stdbool.h>

/*
 * Pour réaliser des tests de performance, désactiver tous les 
 * affichages.
 * Pour cela, le plus simple est de redefinir les fonctions principales 
 * en decommentant les 3 lignes suivantes et en commentant l'ancienne 
 * definition de 'eprintf' juste dessous.
 */

#ifdef SILENT

#define printf(fmt, ...) (0)
#define eprintf(fmt, ...) (0)
#define putchar(c) (0)

#else

#define eprintf(...) fprintf (stderr, __VA_ARGS__)

#endif

extern bool silent_mode;




struct cellule {
    char   command;
    /* vous pouvez rajouter d'autres champs ici */
    struct cellule *suivant;
};
typedef struct cellule cellule_t;

struct sequence {
    cellule_t *tete;
};
typedef struct sequence sequence_t;

struct cellule_n {
    int valeur;
    sequence_t *seq;
    struct cellule_n *suivant;
};
typedef struct cellule_n cellule_n;

struct liste {
    cellule_n *tete;};
typedef struct liste pile;

cellule_t* nouvelleCellule (void);

void detruireCellule (cellule_t*);
void ajout_en_queue(sequence_t *l, char n);
void empiller(pile *l, int n,sequence_t *seq);
void conversion(char *texte, sequence_t *seq);
int depiller_entiers (pile *l);
sequence_t *depiller_seq(pile *l);
void afficher_pile(pile *p);
cellule_t *lire_bloc_commandes(cellule_t *cell, pile *p);
void afficher(sequence_t *seq);
void ajouter_routine(sequence_t* seq, cellule_t* cel, sequence_t* seq_a_ajouter);
cellule_t *ajouter_routine_sans_enlever_B(sequence_t *seq, cellule_t *cel_prec, cellule_t *cel, sequence_t *seq_a_ajouter);
void supprimer_cellule(sequence_t *seq, cellule_t *cel);
void inversion(pile *p);
void clone(pile *p);
void rotation(pile *p);
#endif