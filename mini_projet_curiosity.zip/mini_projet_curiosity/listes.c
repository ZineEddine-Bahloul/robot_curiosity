#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#ifdef NCURSES
#include <ncurses.h>
#endif
#include "listes.h"


/*
 *  Auteur(s) :
 *  Date :
 *  Suivi des Modifications :
 *
 */

bool silent_mode = false;


cellule_t* nouvelleCellule (void)
{
    /* À compléter (utiliser malloc) */
    cellule_t *cell = malloc(sizeof(cellule_t));
    return cell;
}


void detruireCellule (cellule_t* cel)
{
    /* À compléter (utiliser free) */
    free(cel);
}

void ajout_en_queue(sequence_t *l, char n) {
  cellule_t *cell_fin=malloc(sizeof(cellule_t));
  cell_fin->command = n;
  cell_fin->suivant=NULL;
  if (l->tete==NULL){
      l->tete = cell_fin;
      return ;
  }
  cellule_t *cell_cur = l->tete;
  while (cell_cur->suivant != NULL){
      cell_cur=cell_cur->suivant;
  }
  cell_cur->suivant=cell_fin;
return;}

void empiller(pile *l, int n,sequence_t *seq) {
    cellule_n *cell = malloc(sizeof(cellule_n));
    if (cell != NULL){
        cell->valeur = n;
        cell->seq = seq;
        cell->suivant = l->tete;
        l->tete=cell;
    }
}


int depiller_entiers (pile *l){
    int ret = (l->tete)->valeur;
    l->tete = (l->tete)->suivant;
    return ret;
}

sequence_t *depiller_seq(pile *l){
    sequence_t *ret = malloc(sizeof(sequence_t));
    ret = (l->tete)->seq;
    l->tete = (l->tete)->suivant;
    return ret;
}

void conversion (char *texte, sequence_t *seq)
{
  /* À compléter */
  seq->tete = NULL;
  unsigned long len = strlen(texte);
  for (unsigned long i = 0; i < len;i++){
    if (texte[i] !=' ')
      ajout_en_queue(seq, texte[i]);
  }
}







void afficher (sequence_t* seq)
{
    assert (seq); /* Le pointeur doit être valide */
    /* À compléter */
    cellule_t *c;
    if (seq->tete==NULL) {
        //printf("\n");
        }
    else {
        c = seq->tete;
        while (c!=NULL) {
        printf(" %c",c->command );
        c = c->suivant;}
        //printf("\n");
        }
    return;}

/* afficher la pile */
void afficher_pile(pile* p){
    cellule_n *cel = p->tete;
    while (cel != NULL){
        if (cel->seq == NULL){
            printf(" %d", cel->valeur);
        }
        else {
            afficher(cel->seq);
        }
        cel = cel->suivant;
    }
}

cellule_t *lire_bloc_commandes(cellule_t *cell, pile *p){
    sequence_t *seq1 = malloc(sizeof(sequence_t));
    int cmpt1 = 1;
    int cmpt2 = 0;
    char c = cell->command;
    ajout_en_queue(seq1, c) ;
    while (cmpt1 != cmpt2){
        cell = cell->suivant;
        c = cell->command;
        if (c=='{'){
            cmpt1++;
        }
        else if (c=='}')
        {
            cmpt2++;
        }
        ajout_en_queue(seq1, c);
        }
    empiller(p, -1, seq1);
    return cell;
}

void ajouter_routine(sequence_t* seq, cellule_t* cel, sequence_t* seq_a_ajouter){
    cellule_t *cel_cour = seq_a_ajouter->tete;
    cellule_t *cel_prec = NULL;
    while (cel_cour->suivant != NULL){
        cel_prec = cel_cour;
        cel_cour = cel_cour->suivant;
    }
    cel_prec->suivant = cel->suivant; //on met cel_prec pour éliminer la dernière accolade
    cel->suivant = (seq_a_ajouter->tete)->suivant; // on met (seq_a_ajouter->tete)->suivant pour éliminer la première accolade
}
cellule_t* ajouter_routine_sans_enlever_B (sequence_t* seq, cellule_t* cel_prec_B,cellule_t* cel, sequence_t* seq_a_ajouter){

    //sequence_t *cmd = malloc(sizeof(sequence_t));
    cellule_t *cel_cour = (seq_a_ajouter->tete)->suivant;
    //cellule_t *cel_cmd = NULL;
    //int tete = 0;
    while ((cel_cour->suivant) != NULL)
    {
        cel_cour = cel_cour->suivant;
    }
    //cellule_t *cel_B_suivant= cel->suivant;
    //cel->suivant = cmd->tete;
    //cel_cour->suivant = cel;
    //cel_cour->suivant->suivant = cel_B_suivant;
    return cel_cour;
}

void supprimer_cellule(sequence_t *seq, cellule_t* cel){
    cellule_t *cel_cour = seq->tete;
    while(cel_cour->suivant != cel){
        cel_cour = cel_cour->suivant;
    }
    cel_cour->suivant = cel->suivant;
}

void inversion(pile *p) {
  if (p->tete != NULL){
      cellule_n *first = p->tete;
      cellule_n *second = first;
      cellule_n *cell_cur = first->suivant;
      while (cell_cur != NULL){
        p->tete=cell_cur;
        first->suivant=cell_cur->suivant;
        cell_cur->suivant = second;
        second=cell_cur;
        cell_cur=first->suivant;
      }
  }
return;
}

void clone(pile *p){
    cellule_n *cel = p->tete;

    if(cel->seq == NULL){
        empiller(p, cel->valeur,NULL);
    }

    else{
        sequence_t *seq1 = malloc(sizeof(sequence_t));
        seq1->tete = NULL;
        sequence_t *seq0 = (p->tete)->seq;
        cellule_t *cel_cour = seq0->tete;
        while (cel_cour != NULL){
            ajout_en_queue(seq1, cel_cour->command);
            cel_cour = cel_cour->suivant;
        }
        empiller(p, -1,seq1);
    }
}

void rotation(pile* p){
    int pas = depiller_entiers(p);
    int n = depiller_entiers(p);
     
    while (pas != n && pas>0){

        cellule_n *cel_cour = p->tete;
        for (int i = 0; i < n-2; i++){
            cel_cour = cel_cour->suivant;
        }
        if((cel_cour->suivant)->seq != NULL)
            empiller(p,-1,(cel_cour->suivant)->seq);
        else
            empiller(p, (cel_cour->suivant)->valeur,NULL);
        cel_cour->suivant = (cel_cour->suivant)->suivant;
        pas--;
    }
}