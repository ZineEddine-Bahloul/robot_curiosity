#ifndef INTERPRETE_H
#define INTERPRETE_H

int interprete (sequence_t* seq, bool debug);

#endif
