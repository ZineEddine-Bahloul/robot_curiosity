#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#include <stdlib.h>
#ifdef NCURSES
#include <ncurses.h>
#endif
#include "listes.h"
#include "curiosity.h"


/*
 *  Auteur(s) :
 *  Date :
 *  Suivi des Modifications :
 *
 */

void stop (void)
{
    char enter = '\0';
    printf ("Appuyer sur entrée pour continuer...\n");
    while (enter != '\r' && enter != '\n') { enter = getchar(); }
}



int interprete (sequence_t* seq, bool debug)
{
    // Version temporaire a remplacer par une lecture des commandes dans la
    // liste chainee et leur interpretation.

    char commande;

    debug = true; /* À enlever par la suite et utiliser "-d" sur la ligne de commandes */

    printf ("Programme:");
    afficher(seq);
    printf ("\n");
    if (debug) stop();

    // À partir d'ici, beaucoup de choses à modifier dans la suite.
    //printf("\n>>>>>>>>>>> A Faire : interprete.c/interprete() <<<<<<<<<<<<<<<<\n");
    cellule_t *cell = seq->tete;
    commande = cell->command; //à modifier: premiere commande de la sequence
    int ret;         //utilisée pour les valeurs de retour
    pile p;
    p.tete = NULL;
    int n;
    sequence_t *V = NULL;
    sequence_t *F = NULL;
    sequence_t *e  = NULL;
    cellule_t* cel_prec = NULL;
    cellule_t *cell_B = NULL;
    cellule_t *cell_exec = NULL;
    while (cell != NULL)
    { //à modifier: condition de boucle

        switch (commande) {
            /* Ici on avance tout le temps, à compléter pour gérer d'autres commandes */

            case 'A':
                ret = avance();
                if (ret == VICTOIRE) return VICTOIRE; /* on a atteint la cible */
                if (ret == RATE)     return RATE;     /* tombé dans l'eau ou sur un rocher */
                break; /* à ne jamais oublier !!! */
            case 'D':
                droite();
                break;
            case 'G':
                gauche();
                break;
            case '0':
                empiller(&p, 0, NULL);
                break;
            case '1':
                empiller(&p, 1,NULL);
                break;
            case '2':
                empiller(&p, 2,NULL);
                break;
            case '3':
                empiller(&p, 3,NULL);
                break;
            case '4':
                empiller(&p, 4,NULL);
                break;
            case '5':
                empiller(&p, 5,NULL);
                break;
            case '6':
                empiller(&p, 6,NULL);
                break;
            case '7':
                empiller(&p, 7,NULL);
                break;
            case '8':
                empiller(&p, 8,NULL);
                break;
            case '9':
                empiller(&p, 9,NULL);
                break;
            case '+' :
                empiller(&p, depiller_entiers(&p) + depiller_entiers(&p),NULL);
                break;
            case '*' :
                empiller(&p, depiller_entiers(&p) * depiller_entiers(&p),NULL);
                break;
            case '-' :
                empiller(&p, -depiller_entiers(&p) + depiller_entiers(&p),NULL);
                break;
            case 'M':
                empiller(&p,mesure(depiller_entiers(&p)),NULL);
                break;
            case 'P':
                pose(depiller_entiers(&p));
                break;
            case '{':
                cell = lire_bloc_commandes(cell, &p);
                break;
            case '?': 
                F = depiller_seq(&p);
                //afficher(V);
                V = depiller_seq(&p);
                n = depiller_entiers(&p);
                //afficher(F);
                if (n != 0)
                {
                    ajouter_routine(seq,cell,V);
                }
                else {
                    ajouter_routine(seq, cell,F);
                }
                break;
            case 'Z' :
                inversion(&p);
                break;
            case 'X' :
                F = depiller_seq(&p);
                V = depiller_seq(&p);
                empiller(&p, -1, F);
                empiller(&p, -1, V);
                break;
            case '!':
                cell_exec = cell;
                e = depiller_seq(&p);
                cell = e->tete;
                // ajouter_routine(seq, cell,e);
                break;
            case 'B': // ne marche pas jusqu'à présent
                cell_B = cell;
                n = depiller_entiers(&p);
                F = depiller_seq(&p);
                if (n>0){
                    empiller(&p,-1, F);
                    empiller(&p, n - 1,NULL);
                    cell = F->tete->suivant;
                }
                else{
                    depiller_entiers(&p);
                    depiller_seq(&p);
                    supprimer_cellule(seq, cell);
                }
                break;
            case 'C':
                clone(&p);
                break;

            case 'I':
                if((p.tete)->seq == NULL)
                    depiller_entiers(&p);
                else
                    depiller_seq(&p);
                break;

            case 'R':
                rotation(&p);
                break;

            default:
                eprintf("Caractère inconnu: '%c'\n", commande);
        }

        /* Affichage pour faciliter le debug */
        afficherCarte();
        printf ("Programme:");
        afficher(seq);
        printf ("\n");
        afficher_pile(&p);
        printf ("\n");
        if (debug)
            stop();
        cel_prec = cell;
        if (cell->suivant->suivant == NULL){
            if (cell_B != NULL){
                cell = cell_B;
                commande = cell->command;
            }
            else {
                cell = cell_exec;
                cell = cell->suivant;
                commande = cell->command;
            }
        }
        else {
        cell = cell->suivant;
        commande = cell->command;
        }
        printf("------------%c-------------",commande);
    }

    /* Si on sort de la boucle sans arriver sur la cible,
     * c'est raté :-( */

    return CIBLERATEE;
}
